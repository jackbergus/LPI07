package Lez09.imdb.simple;

public class Driver {

    public static void main(String[] args) {
    }

}
