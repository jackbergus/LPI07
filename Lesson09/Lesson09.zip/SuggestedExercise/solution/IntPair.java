public class IntPair {
    private int by;
    private int acc;

    public IntPair(int by, int acc) {
        this.by = by;
        this.acc = acc;
    }

    public int getBy() {
        return by;
    }

    public int getAcc() {
        return acc;
    }

    public void setAcc(int acc) {
        this.acc = acc;
    }
}
