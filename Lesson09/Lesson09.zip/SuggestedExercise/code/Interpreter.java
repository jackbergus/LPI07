import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;

public class Interpreter  {

    public Interpreter(File f) throws FileNotFoundException {
    }

    public void evaluate() {
        System.out.println("Evaluate here");
    }

}
